﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace JSIPManager.Manager
{
    internal class CRegistryManagement
    {
        Microsoft.Win32.RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run\", true);

        public void SetRegistryValue(string strProgramName, string strProgramPath)
        {
            if (registryKey.GetValue(strProgramName) == null)
            {
                registryKey.SetValue(strProgramName, strProgramPath);
            }
        }

        public void SetRegistryDeleteValue(string strProgramName)
        {
            if (registryKey.GetValue(strProgramName) != null)
            {
                registryKey.DeleteValue(strProgramName, false);
            }
        }
    }
}

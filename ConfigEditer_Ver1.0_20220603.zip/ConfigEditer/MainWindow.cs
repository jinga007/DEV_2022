﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ConfigEditer
{
    public partial class firmConfigEditer : Form
    {
        List<StringBuilder> lstdoc = new List<StringBuilder>();
        List<string> _lstFileName = new List<string>();
        List<string> _lstFilePaths = new List<string>();
        string strDefaultFilePaht = @"C:\";
        string strServer = @"localhost\SQLEXPRESS";
        string strUserID = @"sa";
        string strPassword = @"agvagv";
        string strDBListPath = @"DBList.Config";

        public firmConfigEditer()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitailControls();
        }


        #region Controls initial

        private void InitailControls()
        {
            this.txtFolder.Text = strDefaultFilePaht;
            this.tabControl.TabPages.Clear();

            this.listView.BeginUpdate();
            this.listView.View = View.Details;
            this.listView.Columns.Add("이름", 100, HorizontalAlignment.Left);
            this.listView.Columns.Add("날짜", 100, HorizontalAlignment.Left);
            this.listView.Columns.Add("확장자", 100, HorizontalAlignment.Left);
            this.listView.EndUpdate();

            this.txtServer.Text = strServer;
            this.txtUser.Text = strUserID;
            this.txtPassWord.Text = strPassword;

            LoadDataBaseList();
        }

        #endregion

        #region User Fuction
        void FindRootFolder()
        {
            try
            {
                string strDefaultFolderPath = strDefaultFilePaht;
                FolderBrowserDialog dialog = new FolderBrowserDialog();
                dialog.SelectedPath = strDefaultFolderPath;
                dialog.ShowDialog(this);
                this.txtFolder.Text = dialog.SelectedPath;
            }
            catch(Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }

        void ClearAll()
        {
            this.tabControl.TabPages.Clear();
            this.listView.Clear();
            lstdoc.Clear();
            _lstFilePaths.Clear();
            _lstFileName.Clear();
        }

        void LoadConfigFile()
        {
            try
            {
                ClearAll();
                DirectoryInfo RootdirectoryInfo = new DirectoryInfo(this.txtFolder.Text);

                System.IO.FileInfo[] files0 = RootdirectoryInfo.GetFiles();
                var lstFiles0 = files0.Where(x => x.Extension.ToString().ToUpper().Equals(".CONFIG")).ToList();

                foreach (var fileItem0 in lstFiles0)
                {
                    _lstFilePaths.Add($@"{this.txtFolder.Text}\{fileItem0.ToString()}");
                    _lstFileName.Add(fileItem0.ToString());

                    StringBuilder Doc = new StringBuilder();
                    string[] Stream = System.IO.File.ReadAllLines($@"{this.txtFolder.Text}\{fileItem0.ToString()}");
                    foreach (var item in Stream)
                    {
                        Doc.AppendLine(item.ToString());
                    }
                    lstdoc.Add(Doc);

                    ListViewItem lvi = new ListViewItem(fileItem0.ToString());
                    lvi.SubItems.Add(fileItem0.LastWriteTime.ToString());
                    lvi.SubItems.Add(fileItem0.Extension.ToString());
                    lvi.ImageIndex = 0;
                    this.listView.Items.Add(lvi);
                }


                string[] dirs = Directory.GetDirectories(RootdirectoryInfo.FullName.ToString());
                this.listView.BeginUpdate();
                this.listView.View = View.Details;
                this.listView.Columns.Add("이름", 100, HorizontalAlignment.Left);
                this.listView.Columns.Add("날짜", 100, HorizontalAlignment.Left);
                this.listView.Columns.Add("확장자", 100, HorizontalAlignment.Left);

                foreach (var dirItem in dirs)
                {
                    DirectoryInfo directoryInfo = new DirectoryInfo(dirItem);
                    System.IO.FileInfo[] files1 = directoryInfo.GetFiles();
                    var lstFiles1 = files1.Where(x => x.Extension.ToString().ToUpper().Equals(".CONFIG")).ToList();

                    foreach (var filItem1 in lstFiles1)
                    {
                        _lstFilePaths.Add($@"{dirItem.ToString()}\{filItem1.ToString()}");
                        _lstFileName.Add(filItem1.ToString());

                        StringBuilder Doc = new StringBuilder();
                        string[] Stream = System.IO.File.ReadAllLines($@"{dirItem.ToString()}\{filItem1.ToString()}", System.Text.Encoding.UTF8);

                        foreach (var item in Stream)
                        {
                            Doc.AppendLine(item.ToString());
                        }
                        lstdoc.Add(Doc);

                        ListViewItem lvi = new ListViewItem(filItem1.ToString());
                        lvi.SubItems.Add(filItem1.LastWriteTime.ToString());
                        lvi.SubItems.Add(filItem1.Extension.ToString());
                        lvi.ImageIndex = 0;
                        this.listView.Items.Add(lvi);
                    }
                }

                if (this.listView.Items.Count > 0)
                {
                    this.listView.Items[0].Selected = true;
                    this.listView.Items[0].Focused = true;
                }
                this.listView.EndUpdate();

                int idx = 0;
                #region tabControl Child item 생성
                foreach (var item in lstdoc)
                {
                    RichTextBox richBox = new RichTextBox();
                    richBox.Name = $"rcBox{_lstFileName[idx]}";
                    richBox.Dock = DockStyle.Fill;
                    richBox.Text = item.ToString();

                    TabPage tabP = new TabPage();
                    tabP.Name = $"tabP{_lstFileName[idx]}";
                    tabP.Text = _lstFileName[idx];
                    tabP.Controls.Add(richBox);

                    this.tabControl.TabPages.Add(tabP);

                    idx++;
                }

                #endregion

                #region 기존 파일의  Database Name 과 Server Name  추출
                foreach(TabPage item in this.tabControl.TabPages)
                {
                    if(item .Text == "LGCNS.ezControl.config")
                    {
                        int iDBstart = (item.Controls[0] as RichTextBox).Find("database=", RichTextBoxFinds.MatchCase);
                        int iDBEnd = (item.Controls[0] as RichTextBox).Find(";", iDBstart, RichTextBoxFinds.MatchCase);
                        int iSSstart = (item.Controls[0] as RichTextBox).Find("server=", RichTextBoxFinds.MatchCase);
                        int iSSEnd = (item.Controls[0] as RichTextBox).Find(";", iSSstart, RichTextBoxFinds.MatchCase);
                        int iUNstart = (item.Controls[0] as RichTextBox).Find("User ID=", RichTextBoxFinds.MatchCase);
                        int iUNEnd = (item.Controls[0] as RichTextBox).Find(";", iUNstart, RichTextBoxFinds.MatchCase);
                        int iPWstart = (item.Controls[0] as RichTextBox).Find("Password=", RichTextBoxFinds.MatchCase);
                        int iPWEnd = (item.Controls[0] as RichTextBox).Find(";", iPWstart, RichTextBoxFinds.MatchCase);

                        txtDBOld.Text = (item.Controls[0] as RichTextBox).Text.Substring(iDBstart, iDBEnd - iDBstart).Split('=')[1].Trim();
                        txtSSOld.Text = (item.Controls[0] as RichTextBox).Text.Substring(iSSstart, iSSEnd - iSSstart).Split('=')[1].Trim();
                        txtUNOld.Text = (item.Controls[0] as RichTextBox).Text.Substring(iUNstart, iUNEnd - iUNstart).Split('=')[1].Trim();
                        txtPWOld.Text = (item.Controls[0] as RichTextBox).Text.Substring(iPWstart, iPWEnd - iPWstart).Split('=')[1].Trim();
                        break;
                    }
                }
                
                #endregion

               
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }

        void ChangConnectionString()
        {
            try
            {
                foreach (TabPage item in tabControl.TabPages)
                {
                    RichTextBox richBox = (item.Controls[0] as RichTextBox);
                    string strTemp = richBox.Text;
                    strTemp = strTemp.Replace(txtDBOld.Text.Trim(), cmbDataBase.Text.Trim());
                    strTemp = strTemp.Replace(txtSSOld.Text.Trim(), txtServer.Text.Trim());
                    strTemp = strTemp.Replace(txtUNOld.Text.Trim(), txtUser.Text.Trim());
                    strTemp = strTemp.Replace(txtPWOld.Text.Trim(), txtPassWord.Text.Trim());
                    richBox.Clear();
                    richBox.Text = strTemp;
                }

                txtDBOld.Text = cmbDataBase.Text.Trim();
                txtSSOld.Text = txtServer.Text.Trim();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }

        void SaveChangedConfig()
        {
            try
            {
                int idx = 0;
                foreach (TabPage item in tabControl.TabPages)
                {
                    RichTextBox richBox = (item.Controls[0] as RichTextBox);
                    StreamWriter writer = new StreamWriter(_lstFilePaths[idx]);
                    writer.Write(richBox.Text);
                    writer.Close();
                    idx++;
                    System.Threading.Thread.Sleep(500);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }



        #endregion User Function


        private void btnFindFolder_Click(object sender, EventArgs e)
        {
            FindRootFolder(); 
            LoadConfigFile();
        }

        private void btnLoadFile_Click(object sender, EventArgs e)
        {
            LoadConfigFile();
        }

        private void btnChangeConfig_Click(object sender, EventArgs e)
        {
            ChangConnectionString();
            
        }

        private void listView_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            try
            {
                foreach (var item in this.tabControl.TabPages)
                {
                    if (item.ToString().Contains(e.Item.Text))
                    {
                        this.tabControl.SelectTab((item as TabPage).Name);
                    }
                }


            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }

        private void lblOldText_DoubleClick(object sender, EventArgs e) => LoadDataBaseList();

        private void LoadDataBaseList()
        {
            this.cmbDataBase.Items.Clear();
            StringBuilder sbDatabases = new StringBuilder();
            using (StreamReader sr = File.OpenText(strDBListPath))
            {
                string s;
                while ((s = sr.ReadLine()) != null)
                {
                    sbDatabases.Append(s);
                }
            }

            string[] databases = sbDatabases.ToString().Split(';');
            this.cmbDataBase.Items.AddRange(databases);
            this.cmbDataBase.Items.RemoveAt(this.cmbDataBase.Items.Count - 1);
            this.cmbDataBase.SelectedIndex = 0;
        }

        private void lblDatabase_MouseHover(object sender, EventArgs e)
        {
            ToolTip ttDB = new ToolTip();
            ttDB.ToolTipTitle = "Information";
            ttDB.IsBalloon = true;
            ttDB.SetToolTip(this.lblDatabase, "더블클릭하면 콤포박스 리플레쉬됨\n등록된Database 항목은 DBList.Config에 있으로 수정필요시 파일을 열어 수정하며됨");
        }

        private void btnMMDEdit_Click(object sender, EventArgs e)
        {
            ConfigEditer.Windows.DBListEditerWindow _win = new Windows.DBListEditerWindow();
            _win.ShowDialog(this);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveChangedConfig();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigEditer.Data
{
    internal class DBConnection
    {
        public string DB_NAME{ get; set; }
        public string SERVER { get; set; }
        public string USER_NAME { get; set; }
        public string PASS_WRD { get; set; }

    }

    internal class DBConnectionList 
    {
        List<DBConnection >_DBConnections = new List<DBConnection>();

        public List<DBConnection> DBConnections 
        { 
            get { return _DBConnections; }
                
        }

        public void _Add(DBConnection obj)
        {
            _DBConnections.Add(obj);
        }
    }


    
}

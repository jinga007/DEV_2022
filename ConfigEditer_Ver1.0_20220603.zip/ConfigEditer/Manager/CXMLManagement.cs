﻿using System;
using System.Collections.ObjectModel;
using System.Xml;
using System.Xml.Linq;

using ConfigEditer.Data;

namespace Manager
{
    internal class CXMLManagement
    {
        public CXMLManagement()
        {

        }

        internal DBConnectionList GetConfigXML(string url = "")
        {
            DBConnectionList _rcvDatas = new DBConnectionList();
            try
            {
                if (string.IsNullOrWhiteSpace(url))
                    url = "DBConnectionString.xml";

                try
                {
                    XmlDocument xml = new XmlDocument();
                    xml.Load(url);
                    XmlNodeList xnList = xml.SelectNodes("DBS/DB");
                    foreach (XmlNode xn in xnList)
                    {
                        DBConnection _rcvData = new DBConnection();
                        _rcvData.DB_NAME = xn["DB_NAME"].InnerText;
                        _rcvData.SERVER = xn["SERVER"].InnerText;
                        _rcvData.USER_NAME = xn["USER_NAME"].InnerText;
                        _rcvData.PASS_WRD = xn["PASS_WRD"].InnerText;
                        _rcvDatas._Add(_rcvData);
                    }
                }
                catch (ArgumentException ex)
                {
                    throw new Exception(ex.Message);
                }

            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);

            }

            return _rcvDatas;
        }

        internal bool SaveConfigXML(DBConnectionList _Datas, string url = "")
        {
            bool _rets = false;

            try
            {
                if (_Datas == null)
                    throw new Exception();

                if (string.IsNullOrWhiteSpace(url))
                    url = "DBConnectionString.xml";

                XDocument xdoc = new XDocument(new XDeclaration("1.0", "UTF-8", null));
                XElement xroot = new XElement("DBS");
                xdoc.Add(xroot);
                int idx = 100;
                foreach (var item in _Datas.DBConnections)
                {
                    XElement xe = new XElement("DB",
                        new XAttribute("Id", (idx++).ToString("000")),
                        new XElement("DB_NAME", item.DB_NAME),
                        new XElement("SERVER", item.SERVER),
                        new XElement("USER_NAME", item.USER_NAME),
                        new XElement("PASS_WRD", item.PASS_WRD)
                        );
                    xroot.Add(xe);
                }
                xdoc.Save(url);
                _rets = true;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }

            return _rets;
        }
    }
}

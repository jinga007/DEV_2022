﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConfigEditer.Data;
using Manager;

namespace ConfigEditer.Windows
{
    public partial class DBListEditerWindow : Form
    {
        DBConnectionList _datas = new DBConnectionList();

        public DBListEditerWindow()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            
            DBConnection _data = new DBConnection();
            _data.DB_NAME = this.txtDBName.Text;
            _data.SERVER = this.txtServer.Text;
            _data.USER_NAME = this.txtUserID.Text;
            _data.PASS_WRD = this.txtPW.Text;
            _datas._Add(_data);

            var dataBinder = new BindingSource();
            dataBinder.DataSource = _datas;
            dGridDB.DataSource = dataBinder;
            //dGridDB.Refresh();


        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < dGridDB.Rows.Count; i++)
                {
                    //행 선택 여부
                    dGridDB.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

                    if (dGridDB.Rows[i].Selected == true)
                    {
                        //현재 선택된 인덱스에 해당된 Row 삭제
                        dGridDB.Rows.Remove(dGridDB.Rows[i]);
                    }

                }
            }
            catch(Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DBConnectionList _Datas = (this.dGridDB.DataSource as DBConnectionList);
            //ObservableCollection<DBConnectionList> _Datas = new ObservableCollection<DBConnectionList>();
            //DataTable dTable =  (DataTable)this.dGridDB.DataSource;
            //this.dGridDB.DataSource;

            //foreach (var row in this.dGridDB.DataSource)
            //{
            //    //DBConnectionList _data = new DBConnectionList();
            //    //(this.dGridDB.DataSource as DBConnectionList)


            //    _Datas.Add(_data);
            //}
            //new CXMLManagement().SaveConfigXML(_Datas);

        }
    }
}

﻿namespace ConfigEditer.Windows
{
    partial class DBListEditerWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dGridDB = new System.Windows.Forms.DataGridView();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.dBConnectionListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dBConnectionsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dBConnectionsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.txtPW = new System.Windows.Forms.TextBox();
            this.lblPW = new System.Windows.Forms.Label();
            this.txtUserID = new System.Windows.Forms.TextBox();
            this.lblUser = new System.Windows.Forms.Label();
            this.txtServer = new System.Windows.Forms.TextBox();
            this.txtDBName = new System.Windows.Forms.TextBox();
            this.lblServer = new System.Windows.Forms.Label();
            this.lblDatabase = new System.Windows.Forms.Label();
            this.dBConnectionsBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.dBConnectionsBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.dBConnectionsBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.dBConnectionListBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dGridDB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBConnectionListBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBConnectionsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBConnectionsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBConnectionsBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBConnectionsBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBConnectionsBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBConnectionListBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // dGridDB
            // 
            this.dGridDB.AllowUserToOrderColumns = true;
            this.dGridDB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGridDB.Location = new System.Drawing.Point(9, 116);
            this.dGridDB.Name = "dGridDB";
            this.dGridDB.RowTemplate.Height = 23;
            this.dGridDB.Size = new System.Drawing.Size(759, 463);
            this.dGridDB.TabIndex = 0;
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnAdd.Location = new System.Drawing.Point(626, 89);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(66, 20);
            this.btnAdd.TabIndex = 26;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnRemove.Location = new System.Drawing.Point(698, 89);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(66, 20);
            this.btnRemove.TabIndex = 27;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnLoad
            // 
            this.btnLoad.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLoad.Location = new System.Drawing.Point(628, 13);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(140, 20);
            this.btnLoad.TabIndex = 28;
            this.btnLoad.Text = "Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnSave.Location = new System.Drawing.Point(628, 40);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(140, 20);
            this.btnSave.TabIndex = 29;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // dBConnectionsBindingSource
            // 
            this.dBConnectionsBindingSource.DataMember = "DBConnections";
            this.dBConnectionsBindingSource.DataSource = this.dBConnectionListBindingSource1;
            // 
            // dBConnectionsBindingSource1
            // 
            this.dBConnectionsBindingSource1.DataMember = "DBConnections";
            this.dBConnectionsBindingSource1.DataSource = this.dBConnectionListBindingSource1;
            // 
            // txtPW
            // 
            this.txtPW.Location = new System.Drawing.Point(93, 89);
            this.txtPW.Name = "txtPW";
            this.txtPW.Size = new System.Drawing.Size(528, 21);
            this.txtPW.TabIndex = 37;
            // 
            // lblPW
            // 
            this.lblPW.AutoSize = true;
            this.lblPW.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblPW.Location = new System.Drawing.Point(7, 94);
            this.lblPW.Name = "lblPW";
            this.lblPW.Size = new System.Drawing.Size(70, 12);
            this.lblPW.TabIndex = 36;
            this.lblPW.Text = "Password";
            // 
            // txtUserID
            // 
            this.txtUserID.Location = new System.Drawing.Point(93, 62);
            this.txtUserID.Name = "txtUserID";
            this.txtUserID.Size = new System.Drawing.Size(528, 21);
            this.txtUserID.TabIndex = 35;
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblUser.Location = new System.Drawing.Point(7, 67);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(53, 12);
            this.lblUser.TabIndex = 34;
            this.lblUser.Text = "User ID";
            // 
            // txtServer
            // 
            this.txtServer.Location = new System.Drawing.Point(93, 35);
            this.txtServer.Name = "txtServer";
            this.txtServer.Size = new System.Drawing.Size(528, 21);
            this.txtServer.TabIndex = 33;
            // 
            // txtDBName
            // 
            this.txtDBName.Location = new System.Drawing.Point(93, 12);
            this.txtDBName.Name = "txtDBName";
            this.txtDBName.Size = new System.Drawing.Size(528, 21);
            this.txtDBName.TabIndex = 32;
            // 
            // lblServer
            // 
            this.lblServer.AutoSize = true;
            this.lblServer.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblServer.Location = new System.Drawing.Point(7, 40);
            this.lblServer.Name = "lblServer";
            this.lblServer.Size = new System.Drawing.Size(47, 12);
            this.lblServer.TabIndex = 31;
            this.lblServer.Text = "Server";
            // 
            // lblDatabase
            // 
            this.lblDatabase.AutoSize = true;
            this.lblDatabase.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblDatabase.Location = new System.Drawing.Point(7, 15);
            this.lblDatabase.Name = "lblDatabase";
            this.lblDatabase.Size = new System.Drawing.Size(66, 12);
            this.lblDatabase.TabIndex = 30;
            this.lblDatabase.Text = "Database";
            // 
            // dBConnectionsBindingSource2
            // 
            this.dBConnectionsBindingSource2.DataMember = "DBConnections";
            this.dBConnectionsBindingSource2.DataSource = this.dBConnectionListBindingSource1;
            // 
            // dBConnectionsBindingSource3
            // 
            this.dBConnectionsBindingSource3.DataMember = "DBConnections";
            this.dBConnectionsBindingSource3.DataSource = this.dBConnectionListBindingSource1;
            // 
            // dBConnectionsBindingSource4
            // 
            this.dBConnectionsBindingSource4.DataMember = "DBConnections";
            this.dBConnectionsBindingSource4.DataSource = this.dBConnectionListBindingSource1;
            // 
            // dBConnectionListBindingSource1
            // 
            this.dBConnectionListBindingSource1.DataSource = typeof(ConfigEditer.Data.DBConnectionList);
            // 
            // DBListEditerWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(774, 579);
            this.Controls.Add(this.txtPW);
            this.Controls.Add(this.lblPW);
            this.Controls.Add(this.txtUserID);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.txtServer);
            this.Controls.Add(this.txtDBName);
            this.Controls.Add(this.lblServer);
            this.Controls.Add(this.lblDatabase);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dGridDB);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DBListEditerWindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "List";
            ((System.ComponentModel.ISupportInitialize)(this.dGridDB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBConnectionListBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBConnectionsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBConnectionsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBConnectionsBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBConnectionsBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBConnectionsBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBConnectionListBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dGridDB;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.BindingSource dBConnectionListBindingSource;
        private System.Windows.Forms.BindingSource dBConnectionListBindingSource1;
        private System.Windows.Forms.BindingSource dBConnectionsBindingSource1;
        private System.Windows.Forms.BindingSource dBConnectionsBindingSource;
        private System.Windows.Forms.TextBox txtPW;
        private System.Windows.Forms.Label lblPW;
        private System.Windows.Forms.TextBox txtUserID;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.TextBox txtServer;
        private System.Windows.Forms.TextBox txtDBName;
        private System.Windows.Forms.Label lblServer;
        private System.Windows.Forms.Label lblDatabase;
        private System.Windows.Forms.BindingSource dBConnectionsBindingSource2;
        private System.Windows.Forms.BindingSource dBConnectionsBindingSource4;
        private System.Windows.Forms.BindingSource dBConnectionsBindingSource3;
    }
}
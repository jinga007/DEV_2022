﻿using JSIPManager.Windows;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace JSIPManager.Manager
{
    internal static class CTrayIConManagement
    {
        public static System.Windows.Forms.NotifyIcon notifyIcon = null;
        public static void SetTryIcon(object Sender)
        {
            if (notifyIcon != null)
            {
                return;
            }

            notifyIcon = new System.Windows.Forms.NotifyIcon();
            notifyIcon.Icon = JSIPManager.Properties.Resources.Moon;
            notifyIcon.Visible = true;
            notifyIcon.Text = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).FileDescription.ToString();// "JSIPManager.";

            notifyIcon.DoubleClick += delegate (object sender, EventArgs e)
            {
                (Sender as Window).Show();
                (Sender as Window).WindowState = WindowState.Normal;
            };

            System.Windows.Forms.ContextMenu TIconMenu = new System.Windows.Forms.ContextMenu();
            System.Windows.Forms.MenuItem item1 = new System.Windows.Forms.MenuItem();
            item1.Text = FORM_STATUS.SHOW;
            item1.Click += delegate (object sender, EventArgs e)
            {
                (Sender as Window).Show();
                (Sender as Window).WindowState = WindowState.Normal;
            };
            TIconMenu.MenuItems.Add(item1);

            System.Windows.Forms.MenuItem item2 = new System.Windows.Forms.MenuItem();
            item2.Text = FORM_STATUS.HIDDEN;
            item2.Click += delegate (object sender, EventArgs e)
            {
                (Sender as Window).Visibility = Visibility.Hidden;
            };
            TIconMenu.MenuItems.Add(item2);

            System.Windows.Forms.MenuItem item3 = new System.Windows.Forms.MenuItem();
            item3.Text = FORM_STATUS.PINT_TESTER;
            item3.Click += delegate (object sender, EventArgs e)
            {
                PingTestWindow pingWin = new PingTestWindow();
                pingWin.Show();
            };
            TIconMenu.MenuItems.Add(item3);

            System.Windows.Forms.MenuItem item4 = new System.Windows.Forms.MenuItem();
            item4.Text = FORM_STATUS.PORT_SCANNER;
            item4.Click += delegate (object sender, EventArgs e)
            {
                PortScanWindow portScanWin = new PortScanWindow();
                portScanWin.Show();
            };
            TIconMenu.MenuItems.Add(item4);

            System.Windows.Forms.MenuItem item5 = new System.Windows.Forms.MenuItem();
            item5.Text = FORM_STATUS.EXIT;
            item5.Click += delegate (object sender, EventArgs e)
            {
                System.Windows.Application.Current.Shutdown();
                notifyIcon.Dispose();
            };
            TIconMenu.MenuItems.Add(item5);

            notifyIcon.ContextMenu = TIconMenu;
        }

        public static void DisposeTrayICon()
        {
            if (notifyIcon != null)
            {
                notifyIcon.Dispose();
                notifyIcon = null;
            }
        }
    }
}
